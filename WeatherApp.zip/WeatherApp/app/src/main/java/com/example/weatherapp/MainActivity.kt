package com.example.weatherapp

import android.Manifest
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.LocationManager
import android.os.AsyncTask
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var sp: SharedPreferences


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tv:TextView = findViewById(R.id.textView)
        val get: Button = findViewById(R.id.button)
        val search:Button = findViewById(R.id.select)

        ActivityCompat.requestPermissions(MainActivity@this,
            arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION),
            569)

        val prog: ProgressDialog = ProgressDialog(MainActivity@this)
        prog.setMessage("Getting Your location...")
        prog.setTitle("Please wait")


        val locObject:MyLocationClass = MyLocationClass(tv, prog)
        val locManager : LocationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        prog.show()

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

        }
        locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0f, locObject)

        sp = getSharedPreferences("LocationData", Context.MODE_PRIVATE)
        val dataEditor : SharedPreferences.Editor = sp.edit()

        get.setOnClickListener({

            val locationConverter: Geocoder = Geocoder(MainActivity@ this, Locale.getDefault())
            val addr: List<Address> = locationConverter.getFromLocation(locObject.Latitude(), locObject.Longitude(), 1)
            val finalAddress = addr[0]

            //dataEditor.putString("Lat", "${locObject.Latitude()}")
            //dataEditor.putString("Lon", "${locObject.Longitude()}")

            dataEditor.putString("City", finalAddress.subAdminArea)

            dataEditor.apply()
            dataEditor.commit()

            startActivity(Intent(this, ShowWeather::class.java))
            finish()
        })

        search.setOnClickListener({
            startActivity(Intent(this, SearchCity::class.java))
            finish()
        })

    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if(grantResults[0] == PackageManager.PERMISSION_GRANTED) {

        }
    }
}
