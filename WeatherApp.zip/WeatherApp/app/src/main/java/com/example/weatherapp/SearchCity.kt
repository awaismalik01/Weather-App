package com.example.weatherapp

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import androidx.core.widget.addTextChangedListener

class SearchCity : AppCompatActivity() {

    lateinit var sp: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search_city)

        var TheFilter:EditText = findViewById(R.id.SearchFilter)

        var myListView : ListView = findViewById(R.id.myListView)
        var cityNames = listOf<String>("Abbottabad", "Adilpur", "Ahmadpur", "Akora", "Alik Ghund", "Alipur", "Aman Garh", "Arifwala", "Attock", "Baddomalhi",
            "Badin", "Baffa", "Bagarji", "Bahawalnagar", "Bahawalnagar", "Bahawalpur", "Bandhi", "Bannu", "Barkhan", "Basirpur", "Bat Khela", "Battagram",
                    "Begowala", "Bela", "Berani", "Bhag", "Bhakkari", "Bhalwal", "Bhan", "Bhawana", "Bhera", "himbar", "Bhiria", "Bhit Shah", "Bhopalwala",
                    "Bozdar Wada", "Burewala", "Chak", "Chak Azam Sahu", "Chak Jhumra", "Chakwal", "Chaman", "Chamber", "Chawinda", "Chenab Nagar", "Chhor",
                    "Chichawatni", "Chiniot", "Chishtian", "Choa Saidan Shah", "Chuchar-kana Mandi", "Chuhar Jamali", "Chunian", "Dadhar", "Dadu", "Daira Din Panah",
                    "Dajal", "Dalbandin", "Daromehar", "Darya Khan", "Darya Khan Marri", "Daska Kalan", "Daud Khel", "Daulatpur", "Daultala", "Daur", "Dera Bugti",
                    "Dera Ghazi Khan", "Dera Ismail Khan", "Dhanot", "Dhaunkal", "Dhoro Naro", "Digri", "Dijkot", "Dinan Bashnoian Wala", "Dinga", "Dipalpur",
                    "Diplo", "Doaba", "Dokri", "Duki", "Dullewala", "Dunga Bunga", "Dunyapur", "Eminabad", "Faisalabad", "Faqirwali", "Faruka", "Fazilpur",
                    "Fort Abbas", "Gadani", "Gambat", "Garh Maharaja", "Garhi Khairo", "Garhiyasin", "Gharo", "Ghauspur", "Ghotki", "Gilgit", "Gojra",
                    "Goth Garelo", "Goth Phulji", "Goth Radhan", "Gujar Khan", "Gujranwala", "Gujrat", "Gwadar", "Hadali", "Hafizabad", "Hala", "Hangu", "Haripur",
                    "Harnai", "Harnoli", "Harunabad", "Hasilpur", "Haveli Lakha", "Havelian", "Hazro City", "Hingorja", "Hujra Shah Muqim", "Hyderabad", "Islamabad",
                    "Islamkot", "Jacobabad", "Jahanian Shah", "Jalalpur Jattan", "Jalalpur Pirwala", "Jam Sahib", "Jampur", "Jand", "Jandiala Sher Khan",
                    "Jaranwala", "Jati", "Jatoi Shimali", "Jauharabad", "Jhang Sadr", "Jhawarian", "Jhelum", "Jhol", "Jiwani", "Johi", "Kabirwala", "Kadhan",
                    "Kahna Nau", "Kahror Pakka", "Kahuta", "Kalabagh", "Kalaswala", "Kalat", "Kaleke Mandi", "Kallar Kahar", "Kalur Kot", "Kamalia", "Kamar Mushani",
                    "Kambar", "Kamoke", "Kamra", "Kandhkot", "Kandiari", "Kandiaro", "Kanganpur", "Karachi", "Karak", "Karaundi", "Kario Ghanwar", "Karor", "Kashmor",
                    "Kasur", "Khadan Khak", "Khadro", "Khairpur", "Khairpur Mir", "Khairpur Nathan Shah", "Khairpur Tamewah", "Khalabat", "Khangah Dogran")/*
                    Khangarh
                    Khanpur
                    Khanpur Mahar
                    Kharan
                    Kharian
                    Khewra
                    Khurrianwala
                    Khushab
                    Khuzdar
                    Kohat
                    Kohlu
                    Kot Addu
                    Kot Diji
                    Kot Ghulam Muhammad
                    Kot Malik Barkhurdar
                    Kot Mumin
                    Kot Radha Kishan
                    Kot Samaba
                    Kot Sultan
                    Kotli
                    Kotli Loharan
                    Kotri
                    Kulachi
                    Kundian
                    Kunjah
                    Kunri
                    Lachi
                    Ladhewala Waraich
                    Lahore
                    Lakhi
                    Lakki
                    Lala Musa
                    Lalian
                    Larkana
                    Layyah
                    Liliani
                    Lodhran
                    Loralai
                    Mach
                    Madeji
                    Mailsi
                    Malakwal
                    Malakwal City
                    Malir Cantonment
                    Mamu Kanjan
                    Mananwala
                    Mandi Bahauddin
                    Mangla
                    Mankera
                    Mansehra
                    Mardan
                    Mastung
                    Matiari
                    Matli
                    Mehar
                    Mehrabpur
                    Mian Channun
                    Mianke Mor
                    Mianwali
                    Minchianabad
                    Mingora
                    Miro Khan
                    Mirpur Bhtoro
                    Mirpur Khas
                    Mirpur Mathelo
                    Mirpur Sakro
                    Mirwah Gorchani
                    Mitha Tiwana
                    Mithi
                    Moro
                    Multan
                    Muridke
                    Murree
                    Mustafabad
                    Muzaffarabad
                    Muzaffargarh
                    Nabisar
                    Nankana Sahib
                    Narang Mandi
                    Narowal
                    Nasirabad
                    Naudero
                    Naukot
                    Naushahra Virkan
                    Nawabshah
                    Nazir Town
                    New Badah
                    Nowshera Cantonment
                    Nushki
                    Okara
                    Ormara
                    Pabbi
                    Pad Idan
                    Paharpur
                    Pakpattan
                    Pano Aqil
                    Parachinar
                    Pasni
                    Pasrur
                    Pattoki
                    Peshawar
                    Phalia
                    Pind Dadan Khan
                    Pindi Bhattian
                    Pindi Gheb
                    Pir Jo Goth
                    Pir Mahal
                    Pishin
                    Pithoro
                    Quetta
                    Raiwind
                    Raja Jang
                    Rajanpur
                    Rajo Khanani
                    Ranipur
                    Rasulnagar
                    Ratodero
                    Rawala Kot
                    Rawalpindi
                    Renala Khurd
                    Risalpur Cantonment
                    Rohri
                    Rojhan
                    Rustam
                    Saddiqabad
                    Sahiwal
                    Sahiwal
                    Sakrand
                    Samaro
                    Sambrial
                    Sanghar
                    Sangla Hill
                    Sanjwal
                    Sann
                    Sarai Alamgir
                    Sarai Naurang
                    Sarai Sidhu
                    Sargodha
                    Sehwan
                    Setharja Old
                    Shabqadar
                    Shahdad Kot
                    Shahdadpur
                    Shahkot
                    Shahpur
                    Shahpur Chakar
                    Shahr Sultan
                    Shakargarh
                    Sharqpur Sharif
                    Shekhupura
                    Shikarpur
                    Shorkot
                    Shujaabad
                    Sialkot
                    Sibi
                    Sillanwali
                    Sinjhoro
                    Sita Road
                    Sobhodero
                    Sodhri
                    Sohbatpur
                    Sukheke Mandi
                    Sukkur
                    Surab
                    Surkhpur
                    Swabi
                    Talagang
                    Talamba
                    Talhar
                    Tandlianwala
                    Tando Adam
                    Tando Allahyar
                    Tando Bago
                    Tando Jam
                    Tando Muhammad Khan
                    Tangi
                    Tangwani
                    Tank
                    Taunsa
                    Thal
                    Tharu Shah
                    Thatta
                    Thul
                    Toba Tek Singh
                    Topi
                    Turbat
                    Ubauro
                    Umarkot
                    Upper Dir
                    Usta Muhammad
                    Uthal
                    Utmanzai
                    Vihari
                    Warah
                    Wazirabad
                    Yazman
                    Zafarwal
                    Zahir Pir
                    Zaida
                    Zhob
        )*/

        var myAdapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1 , cityNames)
        myListView.adapter = myAdapter

        TheFilter.addTextChangedListener(object : TextWatcher
        {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                myAdapter.filter.filter(s)
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })

        sp = getSharedPreferences("LocationData", Context.MODE_PRIVATE)
        val dataEditor : SharedPreferences.Editor = sp.edit()

        myListView.setOnItemClickListener{
                parent, view, position, id ->

            dataEditor.putString("City", cityNames[position])

            dataEditor.apply()
            dataEditor.commit()

            startActivity(Intent(this, ShowWeather::class.java))
            finish()

        }

    }
}