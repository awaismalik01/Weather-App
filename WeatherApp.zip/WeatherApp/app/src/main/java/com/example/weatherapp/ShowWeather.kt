package com.example.weatherapp

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.AsyncTask
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class ShowWeather : AppCompatActivity() {

    lateinit var sp: SharedPreferences
    val CITY: String = "Lahore,PK"
    val API: String = "763d65e303fa323554d5b833d6a0fafc" // Use API key
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_weather)

        ActivityCompat.requestPermissions(MainActivity@this,
            arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION),
            569)

        sp = getSharedPreferences("LocationData", Context.MODE_PRIVATE)

        //val LAT = sp.getString("Lat", "No Data")
        //val LON = sp.getString("Lon", "No Data")

        val CITY = sp.getString("City", "No Data")

        Toast.makeText(this, "$CITY", Toast.LENGTH_SHORT).show()
        weatherTask(this).execute(CITY)

        val Refresh:LinearLayout = findViewById(R.id.RefreshW)
        Refresh.setOnClickListener({
            weatherTask(this).execute(CITY)
        })

        val Search:Button = findViewById(R.id.Search)
        Search.setOnClickListener({
            startActivity(Intent(this, SearchCity::class.java))
        })

    }



    inner class weatherTask(var view: Context) : AsyncTask<String, Void, String>() {


        override fun onPreExecute() {
            super.onPreExecute()

            findViewById<ProgressBar>(R.id.loader).visibility = View.VISIBLE
            findViewById<LinearLayout>(R.id.mainContainer).visibility = View.GONE
            findViewById<TextView>(R.id.errorText).visibility = View.GONE


        }

        override fun doInBackground(vararg params: String?): String? {
            var response: String?
            try {
                response =
                    URL("https://api.openweathermap.org/data/2.5/weather?q=${params[0]}&units=metric&appid=$API").readText(
                        Charsets.UTF_8
                    )

                /*
                response =
                    URL("https://api.openweathermap.org/data/2.5/weather?lat=${params[0]}&lon=${params[1]}&appid=$API").readText(
                        Charsets.UTF_8
                    )
                */
            } catch (e: Exception) {
                response = null
            }
            return response
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            try {
                /* Extracting JSON returns from the API */
                val jsonObj = JSONObject(result)
                val main = jsonObj.getJSONObject("main")
                val sys = jsonObj.getJSONObject("sys")
                val wind = jsonObj.getJSONObject("wind")
                val weather = jsonObj.getJSONArray("weather").getJSONObject(0)

                val updatedAt: Long = jsonObj.getLong("dt")

                val sdf = SimpleDateFormat("dd/M/yyyy hh:mm")
                val currentDate = sdf.format(Date())

                val updatedAtText = "Last Updated at: $currentDate"
                val temp = "" + main.getInt("temp") + "°C"
                val tempMin = "Min Temp: " + main.getInt("temp_min") + "°C"
                val tempMax = "Max Temp: " + main.getInt("temp_max") + "°C"
                val pressure = main.getString("pressure")
                val humidity = main.getString("humidity") + "%"

                val sunrise: Long = sys.getLong("sunrise")
                val sunset: Long = sys.getLong("sunset")
                val windSpeed = wind.getString("speed")
                val weatherDescription = weather.getString("description")

                val address = jsonObj.getString("name") + ", " + sys.getString("country")

                /* Populating extracted data into our views */
                findViewById<TextView>(R.id.address).text = address
                findViewById<TextView>(R.id.updated_at).text = updatedAtText
                findViewById<TextView>(R.id.status).text = weatherDescription.capitalize()
                findViewById<TextView>(R.id.temp).text = temp
                findViewById<TextView>(R.id.temp_min).text = tempMin
                findViewById<TextView>(R.id.temp_max).text = tempMax
                findViewById<TextView>(R.id.sunrise).text =
                    SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(sunrise * 1000))
                findViewById<TextView>(R.id.sunset).text =
                    SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(sunset * 1000))
                findViewById<TextView>(R.id.wind).text = windSpeed
                findViewById<TextView>(R.id.pressure).text = pressure
                findViewById<TextView>(R.id.humidity).text = humidity

                /* Views populated, Hiding the loader, Showing the main design */
                findViewById<ProgressBar>(R.id.loader).visibility = View.GONE
                findViewById<LinearLayout>(R.id.mainContainer).visibility = View.VISIBLE

            } catch (e: Exception) {
                findViewById<ProgressBar>(R.id.loader).visibility = View.GONE
                findViewById<TextView>(R.id.errorText).visibility = View.VISIBLE
            }

        }
    }
}
